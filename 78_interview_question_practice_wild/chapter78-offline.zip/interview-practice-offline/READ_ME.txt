Unzip this folder, then open START_HERE.html in your browser.
Chapter78 contains all547 questions and their worked answers, priority groups, code downloads and diagrams. Related book chapters are included for local reference. Equations use bundled local fonts. Optional external references and pretrained-model downloads need internet; reading the study material does not.
